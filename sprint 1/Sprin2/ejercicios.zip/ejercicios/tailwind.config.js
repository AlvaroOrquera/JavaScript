/** @type {import('tailwindcss').Config} */
export const theme = {
    extend: {
        colors: {
            clifford: '#da373d',
        }
    }
};
export const plugins = [];